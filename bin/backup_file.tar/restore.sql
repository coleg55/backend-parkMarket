--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "parkMarket-dev";
--
-- Name: parkMarket-dev; Type: DATABASE; Schema: -; Owner: cole
--

CREATE DATABASE "parkMarket-dev" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "parkMarket-dev" OWNER TO cole;

\connect -reuse-previous=on "dbname='parkMarket-dev'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: cole
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    category_name character varying(255) NOT NULL
);


ALTER TABLE public.categories OWNER TO cole;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: cole
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO cole;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cole
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: emails; Type: TABLE; Schema: public; Owner: cole
--

CREATE TABLE public.emails (
    id integer NOT NULL,
    email character varying(255) NOT NULL
);


ALTER TABLE public.emails OWNER TO cole;

--
-- Name: emails_id_seq; Type: SEQUENCE; Schema: public; Owner: cole
--

CREATE SEQUENCE public.emails_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.emails_id_seq OWNER TO cole;

--
-- Name: emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cole
--

ALTER SEQUENCE public.emails_id_seq OWNED BY public.emails.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: cole
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    item_name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    price integer,
    contact_type integer,
    contact character varying(255) NOT NULL,
    backup_contact_type integer,
    backup_contact character varying(255) NOT NULL,
    report_count integer,
    location character varying(255),
    state integer,
    image bytea NOT NULL,
    user_id integer,
    category_id integer
);


ALTER TABLE public.posts OWNER TO cole;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: cole
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO cole;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cole
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: cole
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    is_owner boolean DEFAULT false,
    is_admin boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO cole;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: cole
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO cole;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cole
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: emails id; Type: DEFAULT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.emails ALTER COLUMN id SET DEFAULT nextval('public.emails_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: cole
--

COPY public.categories (id, category_name) FROM stdin;
\.
COPY public.categories (id, category_name) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: emails; Type: TABLE DATA; Schema: public; Owner: cole
--

COPY public.emails (id, email) FROM stdin;
\.
COPY public.emails (id, email) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: cole
--

COPY public.posts (id, item_name, description, price, contact_type, contact, backup_contact_type, backup_contact, report_count, location, state, image, user_id, category_id) FROM stdin;
\.
COPY public.posts (id, item_name, description, price, contact_type, contact, backup_contact_type, backup_contact, report_count, location, state, image, user_id, category_id) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cole
--

COPY public.users (id, username, email, password, is_owner, is_admin) FROM stdin;
\.
COPY public.users (id, username, email, password, is_owner, is_admin) FROM '$$PATH$$/3403.dat';

--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cole
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cole
--

SELECT pg_catalog.setval('public.emails_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cole
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cole
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: categories categories_category_name_key; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_category_name_key UNIQUE (category_name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: emails emails_email_key; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.emails
    ADD CONSTRAINT emails_email_key UNIQUE (email);


--
-- Name: emails emails_pkey; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.emails
    ADD CONSTRAINT emails_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: posts posts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cole
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

